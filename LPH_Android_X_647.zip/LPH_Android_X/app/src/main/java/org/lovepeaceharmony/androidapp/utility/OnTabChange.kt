package org.lovepeaceharmony.androidapp.utility

/**
 * OnTabChange
 * Created by Naveen Kumar M on 15/12/17.
 */

interface OnTabChange {

    fun onTabChange(index: Int)
}
