package org.lovepeaceharmony.androidapp.utility

/**
 * OnRefreshCallback
 * Created by Naveen Kumar M on 24/01/18.
 */
interface OnRefreshCallback {
    fun onRefresh()
}